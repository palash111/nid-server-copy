<?php 

ob_start();

if(!isset($_SESSION)) { 
    session_start(); 
}


define("CALLBACK", "https://surokkha.bdgov.pw/bkash/execute-payment.php");



define("BASEURL", "https://tokenized.pay.bka.sh/v1.2.0-beta");

define("APPKEY", "zIKZrgSpRQjl8OUtJRD1RL5Ntc");

define("APPSECRET", "lRyUJUqfzpGgXU6Jez1lxzAwihFXbjwi065pthSS5V1uNwinlhVG");

define("USERNAME", "01791826409");

define("PASSWORD", "_:_}&ZUX)6f");


?>