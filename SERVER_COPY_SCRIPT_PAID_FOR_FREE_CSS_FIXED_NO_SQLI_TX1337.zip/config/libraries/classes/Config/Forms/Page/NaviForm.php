<?php
/**
 * User preferences form
 */

declare(strict_types=1);

namespace PhpMyAdmin\Config\Forms\Page;

class NaviForm extends \PhpMyAdmin\Config\Forms\User\NaviForm
{
}
